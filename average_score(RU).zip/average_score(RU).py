import tkinter as tk
from tkinter import messagebox

numbers = []

def add_number():
    try:
        number = float(entry.get())
        numbers.append(number)
        entry.delete(0, tk.END)  # Очищаем поле ввода
        listbox.insert(tk.END, number)  # Добавляем число в список
    except ValueError:
        messagebox.showerror("Ошибка", "Введите число!")

def calculate_average():
    if not numbers:
        messagebox.showwarning("Ошибка", "Список чисел пуст!")
        return
    average = sum(numbers) / len(numbers)
    messagebox.showinfo("Результат", f"Среднее: {average:.2f}")

root = tk.Tk()
root.geometry("300x300")
root.title("Калькулятор среднего")

# Поле ввода
entry = tk.Entry(root)
entry.pack(pady=5)

# Кнопка "Добавить число"
add_button = tk.Button(root, text="Добавить", command=add_number)
add_button.pack(pady=5)

# Список введённых чисел
listbox = tk.Listbox(root)
listbox.pack(pady=5)

# Кнопка "Рассчитать среднее"
calc_button = tk.Button(root, text="Рассчитать среднее", command=calculate_average)
calc_button.pack(pady=5)

root.mainloop()