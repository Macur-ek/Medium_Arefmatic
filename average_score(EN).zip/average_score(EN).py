import tkinter as tk
from tkinter import messagebox

numbers = []

def add_number():
    try:
        number = float(entry.get())
        numbers.append(number)
        entry.delete(0, tk.END)  # Clearing the input field
        listbox.insert(tk.END, number)  # Add a number to the list
    except ValueError:
        messagebox.showerror("Error", "Enter a number!")

def calculate_average():
    if not numbers:
        messagebox.showwarning("Error", "The list of numbers is empty!")
        return
    average = sum(numbers) / len(numbers)
    messagebox.showinfo("Result", f"Average: {average:.2f}")

root = tk.Tk()
root.geometry("300x300")
root.title("Average calculator")

# Input field
entry = tk.Entry(root)
entry.pack(pady=5)

# Add number button
add_button = tk.Button(root, text="Add", command=add_number)
add_button.pack(pady=5)

# List of entered numbers
listbox = tk.Listbox(root)
listbox.pack(pady=5)

# Calculate average" button
calc_button = tk.Button(root, text="Calculate average", command=calculate_average)
calc_button.pack(pady=5)

root.mainloop()